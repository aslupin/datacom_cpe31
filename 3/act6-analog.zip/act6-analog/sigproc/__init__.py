from .sigproc import Signal,start_notebook,DEFAULT_PLOT_SETTINGS
